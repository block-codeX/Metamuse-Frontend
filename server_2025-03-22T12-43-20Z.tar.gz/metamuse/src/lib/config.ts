export const BACKEND_BASE_URL = process.env.NEXT_PUBLIC_BACKEND_BASE_URL as string || "http://localhost:8000/api/v1";
export const SOCKET_URL = process.env.NEXT_PUBLIC_SOCKET_URL as string || "http://localhost:8000";
export const YJS_URL = process.env.NEXT_PUBLIC_YJS_URL as string || "http://localhost:8000/project";
export const CHAT_URL = process.env.NEXT_PUBLIC_CHAT_URL as string || "ws://localhost:8001";