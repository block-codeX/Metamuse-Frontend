"use client"

export const ProjectWrapper = ({ children }) => {
    return (
        <>
            {children}
        </>
    )
}